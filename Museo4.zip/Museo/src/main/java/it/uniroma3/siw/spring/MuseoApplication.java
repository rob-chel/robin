package it.uniroma3.siw.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MuseoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuseoApplication.class, args);
	}

}
